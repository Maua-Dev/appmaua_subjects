from enum import Enum


class SEMESTER(Enum):
    AN = "AN"
    S1 = "S1"
    S2 = "S2"

