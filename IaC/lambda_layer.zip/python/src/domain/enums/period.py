from enum import Enum


class PERIOD(Enum):
    DAY = "DAY"
    NIGHT = "NIGHT"