from enum import Enum


class SITUATION(Enum):
    APROVADO = 'APROVADO'
    REPROVADO = 'REPROVADO'
    IN_PROGRESS = 'IN_PROGRESS'

